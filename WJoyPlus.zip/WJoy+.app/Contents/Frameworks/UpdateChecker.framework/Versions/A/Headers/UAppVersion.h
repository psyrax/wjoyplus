//
//  UAppVersion.h
//  UpdateChecker
//
//  Created by alxn1 on 17.10.12.
//  Copyright 2012 alxn1. All rights reserved.
//

typedef struct UAppVersion {
    int major;
    int minor;
    int patch;
    int subPatch;
} UAppVersion;
