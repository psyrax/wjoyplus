//
//  WiimoteProtocolBase.h
//  Wiimote
//
//  Created by alxn1 on 06.08.12.
//  Copyright 2012 alxn1. All rights reserved.
//

typedef enum
{
    WiimoteDevicePacketTypeCommand  = 0xA2,
    WiimoteDevicePacketTypeReport   = 0xA1
} WiimoteDevicePacketType;
